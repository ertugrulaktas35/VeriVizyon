const express = require('express');
const path = require('path');

module.exports = function(req, res, next) {
  express.static(path.join(__dirname, '../public'))(req, res, next);
};