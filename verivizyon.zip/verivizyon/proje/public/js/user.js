function getCookie(name) {
    let value = `; ${document.cookie}`;
    let parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

let username = getCookie('user_normal');
let role = getCookie('role_normal');

document.getElementById('top_name').innerHTML = username;
document.getElementById('drop_name').innerHTML = username;
document.getElementById('bottom_name').innerHTML = username;


if (role == 'client'){
    document.getElementById('yetki').style.display = 'none';
    document.getElementById('yetki2').style.display = 'block';
}
if (role == 'admin'){
    document.getElementById('yetki2').style.display = 'none';
    document.getElementById('yetki').style.display = 'block';
}

