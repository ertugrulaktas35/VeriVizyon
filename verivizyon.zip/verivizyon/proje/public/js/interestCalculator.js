// Gizli inputlardan faiz oranlarını almak
function getFaizOrani(faizTuru) {
    if (faizTuru === 'fed') {
        return parseFloat(document.getElementById('fed-faiz').value);
    } else if (faizTuru === 'tcmb') {
        return parseFloat(document.getElementById('tcmb-faiz').value);
    } else if (faizTuru === 'ecb') {
        return parseFloat(document.getElementById('ecb-faiz').value);
    }
}

// Pop-up açma fonksiyonu
function openPopup(faizTuru) {
    document.getElementById('overlay').style.display = 'block';
    document.getElementById('popup').style.display = 'block';
    
    // Faiz oranını gizli inputtan al ve pop-up'ta göster
    document.getElementById('faiz-orani').value = getFaizOrani(faizTuru);
    document.getElementById('faiz-turu-select').value = faizTuru;

    // Custom faiz oranını gizle
    document.getElementById('custom-faiz').style.display = 'none';

    // Eğer custom seçildiyse, inputu enable yapıyoruz
    if (faizTuru === 'custom') {
        // Custom seçildiğinde, faiz oranı inputunu düzenlenebilir hale getiriyoruz
        document.getElementById('faiz-orani').removeAttribute('readonly');
    } else {
        // Diğer faiz türleri seçildiğinde faiz oranını readonly yapıyoruz
        document.getElementById('faiz-orani').setAttribute('readonly', true);
    }
}

// Pop-up kapama fonksiyonu
function closePopup() {
    document.getElementById('popup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

// Faiz türünü değiştirme fonksiyonu
function faizOraniDegistir() {
    let secilenFaizTuru = document.getElementById('faiz-turu-select').value;

    if (secilenFaizTuru === 'custom') {
        document.getElementById('faiz-orani').value = '';  // Custom seçildiyse faiz oranını sıfırla
    } else {
        document.getElementById('faiz-orani').value = getFaizOrani(secilenFaizTuru);  // Diğer türlerde gizli inputtan al
    }

    // Custom faiz oranı inputunu göster
    if (secilenFaizTuru === 'custom') {
        document.getElementById('faiz-orani').removeAttribute('readonly'); // Custom seçildiğinde inputu enable yapıyoruz
    } else {
        document.getElementById('faiz-orani').setAttribute('readonly', true); // Diğer faiz türlerinde inputu readonly yapıyoruz
    }
}

// Faiz hesaplama fonksiyonu
function hesapla() {
    let faizOrani = parseFloat(document.getElementById('faiz-orani').value);   // Faiz oranı
    if (document.getElementById('faiz-turu-select').value === 'custom') {
        faizOrani = parseFloat(document.getElementById('faiz-orani').value); // Custom faiz oranını al
    }

    let vade = parseInt(document.getElementById('vade').value);                // Vade süresi
    let zamanBirimi = document.getElementById('zaman-birimi').value;          // Yıl/Ay/Gün birimi
    let miktar = parseFloat(document.getElementById('miktar').value);         // Ana para (miktar)

    // Vadeyi gün cinsine çevirmek
    let toplamGun = 0;
    if (zamanBirimi === 'yıl') {
        toplamGun = vade * 365;  // 1 yıl = 365 gün
    } else if (zamanBirimi === 'ay') {
        toplamGun = vade * 30;   // 1 ay = 30 gün
    } else if (zamanBirimi === 'gun') {
        toplamGun = vade;       // Günlük
    }

    // Faiz hesaplama: Faiz = Ana Para * Faiz Oranı * Vade (gün cinsinden) / 100 / 365
    let faizHesaplama = (miktar * faizOrani * toplamGun) / (100 * 365);

    // Sonuç
    document.getElementById('sonuc').innerHTML = `Hesaplanan Faiz: ${faizHesaplama.toFixed(2)} TL`;
}
