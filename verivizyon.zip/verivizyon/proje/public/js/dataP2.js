function generateLast24Hours() {
  const labels = [];
  const currentHour = new Date().getHours(); // Şu anki saati alıyoruz (0-23 arasında)
  
  for (let i = 0; i < 24; i++) {
    const hour = (currentHour - i + 24) % 24; // Saatleri geriye doğru alıyoruz, negatif saat olmaması için modül işlemi
    labels.push(`${hour}:00`); // "XX:00" formatında etiketler
  }
  
  return labels.reverse(); // Sonuçları ters çeviriyoruz, en son saatten başlayacak şekilde
}

function generateWeekDays() {
  const daysOfWeek = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const currentDay = new Date().getDay(); // Bugünün haftanın günü (0-6 arasında) alınıyor

  const labels = [];
  for (let i = 0; i < 7; i++) {
    const dayIndex = (currentDay - i + 7) % 7; // Haftanın günlerini geriye doğru alıyoruz, negatif gün olmaması için modül işlemi
    labels.push(daysOfWeek[dayIndex]);
  }

  return labels.reverse(); // Sonuçları ters çeviriyoruz, bugünden başlayarak
}

function generateLast30Days() {
  const labels = [];
  const currentDate = new Date();
  
  for (let i = 0; i < 30; i++) {
    const previousDate = new Date(currentDate);
    previousDate.setDate(currentDate.getDate() - i); // Geçen 30 günü alıyoruz
    labels.push(`${previousDate.getDate()}`);
  }
  
  return labels.reverse(); // Sonuçları ters çeviriyoruz, en son günden başlayacak şekilde
}

function generateLast6Months() {
  const months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
  const currentMonth = new Date().getMonth(); // Bugünün ayını alıyoruz (0-11 arasında)

  const labels = [];
  for (let i = 0; i < 6; i++) {
    const monthIndex = (currentMonth - i + 12) % 12; // Aylara negatif değer girmemek için modül işlemi
    labels.push(months[monthIndex]);
  }

  return labels.reverse(); // Sonuçları ters çeviriyoruz, en son aydan başlayacak şekilde
}

function generateLast12Months() {
  const months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
  const currentMonth = new Date().getMonth(); // Bugünün ayını alıyoruz (0-11 arasında)

  const last12Months = [];
  for (let i = 0; i < 12; i++) {
    const monthIndex = (currentMonth - i + 12) % 12; // Aylara negatif değer girmemek için modül işlemi
    last12Months.push(months[monthIndex]);
  }

  return last12Months.reverse(); // Sonuçları ters çeviriyoruz, en son aydan başlayacak şekilde
}

function processDate(dateString) {
  // 1. T harfini ve sonrası kısmı kaldırıyoruz
  let dateWithoutTime = dateString.split('T')[0];

  // 2. Hedef tarihe (dateWithoutTime) göre kalan gün farkını hesaplıyoruz
  let targetDate = new Date(dateWithoutTime); // Hedef tarih
  let currentDate = new Date(); // Bugün

  // Gün farkını hesaplıyoruz
  let timeDiff = targetDate - currentDate;
  let dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)); // milisaniyeleri gün sayısına çeviriyoruz

  // 3. Sonucu bir obje olarak döndürüyoruz
  return {
      date: dateWithoutTime,
      daysLeft: dayDiff
  };
}

// Etiketler
const labels = {
  '1D': generateLast24Hours(),   // Geçen 24 saat
  '1W': generateWeekDays(),       // Geçen hafta (Bugün dahil)
  '1M': generateLast30Days(),     // Geçen 30 gün
  '6M': generateLast6Months(),    // Geçen 6 ay
  '1Y': generateLast12Months()    // Geçen 12 ay
};

// fetchAssetsData fonksiyonu
async function fetchAssetsData(assetname, timeframe) {
try {
    // API'ye yapılan istek
    const response = await fetch(`/api/assets/${assetname}/${timeframe}`);
    
    // Eğer istek başarılı ise, json formatında döner
    if (!response.ok) {
        throw new Error('Veri çekilemedi');
    }

    const data = await response.json();

    // Gelen veriyi işleyip dönüştürme
    const timeframeData = data[0][timeframe]; // İlgili timeframe verisini al

    // String formatındaki diziyi gerçek diziye dönüştürme
    const parsedData = JSON.parse(timeframeData);

    return parsedData; // Gerçek dizi olarak veriyi döndür
} catch (error) {
    console.error('Veri çekme hatası:', error);
    return []; // Hata durumunda boş array döndür
}
}

const assetsData = async () => {
let assetsData = {
    'nasdaq': {
        'name': 'NASDAQ',
        '1D': { labels: labels['1D'], data: await fetchAssetsData('nasdaq', '1D') },
        '1W': { labels: labels['1W'], data: await fetchAssetsData('nasdaq', '1W') },
        '1M': { labels: labels['1M'], data: await fetchAssetsData('nasdaq', '1M') },
        '1Y': { labels: labels['1Y'], data: await fetchAssetsData('nasdaq', '1Y') },
        '6M': { labels: labels['6M'], data: await fetchAssetsData('nasdaq', '6M') },
        'color': "#FF9900" // NASDAQ için renk
    },
    'sp500': {
        'name': 'S&P 500',
        '1D': { labels: labels['1D'], data: await fetchAssetsData('sp500', '1D') },
        '1W': { labels: labels['1W'], data: await fetchAssetsData('sp500', '1W') },
        '1M': { labels: labels['1M'], data: await fetchAssetsData('sp500', '1M') },
        '1Y': { labels: labels['1Y'], data: await fetchAssetsData('sp500', '1Y') },
        '6M': { labels: labels['6M'], data: await fetchAssetsData('sp500', '6M') },
        'color': "#4CAF50" // S&P 500 için renk
    },
    'dowjones': {
        'name': 'Dow Jones',
        '1D': { labels: labels['1D'], data: await fetchAssetsData('dowjones', '1D') },
        '1W': { labels: labels['1W'], data: await fetchAssetsData('dowjones', '1W') },
        '1M': { labels: labels['1M'], data: await fetchAssetsData('dowjones', '1M') },
        '1Y': { labels: labels['1Y'], data: await fetchAssetsData('dowjones', '1Y') },
        '6M': { labels: labels['6M'], data: await fetchAssetsData('dowjones', '6M') },
        'color': "#1E88E5" // Dow Jones için renk
    },
    'bist100': {
        'name': 'BIST 100',
        '1D': { labels: labels['1D'], data: await fetchAssetsData('bist100', '1D') },
        '1W': { labels: labels['1W'], data: await fetchAssetsData('bist100', '1W') },
        '1M': { labels: labels['1M'], data: await fetchAssetsData('bist100', '1M') },
        '1Y': { labels: labels['1Y'], data: await fetchAssetsData('bist100', '1Y') },
        '6M': { labels: labels['6M'], data: await fetchAssetsData('bist100', '6M') },
        'color': "#FF5722" // BIST 100 için renk
    },
    'bist30': {
        'name': 'BIST 30',
        '1D': { labels: labels['1D'], data: await fetchAssetsData('bist30', '1D') },
        '1W': { labels: labels['1W'], data: await fetchAssetsData('bist30', '1W') },
        '1M': { labels: labels['1M'], data: await fetchAssetsData('bist30', '1M') },
        '1Y': { labels: labels['1Y'], data: await fetchAssetsData('bist30', '1Y') },
        '6M': { labels: labels['6M'], data: await fetchAssetsData('bist30', '6M') },
        'color': "#9C27B0" // BIST 30 için renk
    }
};

fetch('/api/interest/1')
  .then(data => { return data.json() })
  .then(object => {
    document.getElementById('fed-aciklanan').innerHTML = object['aciklanan'];
    document.getElementById('fed-beklenti').innerHTML = object['beklenti'];
    document.getElementById('fed-onceki').innerHTML = object['onceki'];
    document.getElementById('fed-faiz').value = object['aciklanan'];
    document.getElementById('fed_aciklanacak_tarih').innerHTML = processDate(object['aciklanacak_tarih']).date;
    document.getElementById('fed_kalan').innerHTML = processDate(object['aciklanacak_tarih']).daysLeft;
  });

fetch('/api/interest/2')
  .then(data => { return data.json() })
  .then(object => {
    document.getElementById('tcmb-aciklanan').innerHTML = object['aciklanan'];
    document.getElementById('tcmb-beklenti').innerHTML = object['beklenti'];
    document.getElementById('tcmb-onceki').innerHTML = object['onceki'];
    document.getElementById('tcmb-faiz').value = object['aciklanan'];
    document.getElementById('tcmb_aciklanacak_tarih').innerHTML = processDate(object['aciklanacak_tarih']).date;
    document.getElementById('tcmb_kalan').innerHTML = processDate(object['aciklanacak_tarih']).daysLeft;
  });

fetch('/api/interest/3')
  .then(data => { return data.json() })
  .then(object => {
    document.getElementById('ecb-aciklanan').innerHTML = object['aciklanan'];
    document.getElementById('ecb-beklenti').innerHTML = object['beklenti'];
    document.getElementById('ecb-onceki').innerHTML = object['onceki'];
    document.getElementById('ecb-faiz').value = object['aciklanan'];
    document.getElementById('ecb_aciklanacak_tarih').innerHTML = processDate(object['aciklanacak_tarih']).date;
    document.getElementById('ecb_kalan').innerHTML = processDate(object['aciklanacak_tarih']).daysLeft;
  });

document.getElementById('loader1').style.display = 'none';
document.getElementById('loader2').style.display = 'none';
return assetsData;
};
