const mainVerivizyon = (assetsData) => {
  const $ = document;
  // Varsayılan değerler
  let chartOneItem = 'eurostoxx50';
  let chartOneRange = '1M';

  let chartTwoItem = 'dollar_tl'; // İkinci grafik için varsayılan değerler
  let chartTwoRange = '1M';

  // Birinci grafik kontrolleri
  const chartOneItemButtons = $.querySelectorAll('#chart-one-item li');
  chartOneItemButtons.forEach(item => {
    item.addEventListener('click', () => {
      chartOneItemButtons.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      chartOneItem = item.dataset.item;

      if (chartOneItem === 'ALL') {
        chartUpdater(1, chartOneItem, chartOneRange, true, assetsData['eurostoxx50'], assetsData['nikkei225']);
      } else {
        chartUpdater(1, chartOneItem, chartOneRange);
      }
    });
  });

  const chartOneRangeButtons = $.querySelectorAll('#chart-one-range li');
  chartOneRangeButtons.forEach(item => {
    item.addEventListener('click', () => {
      chartOneRangeButtons.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      chartOneRange = item.dataset.range;

      if (chartOneItem === 'ALL') {
        chartUpdater(1, chartOneItem, chartOneRange, true, assetsData['eurostoxx50'], assetsData['nikkei225']);
      } else {
        chartUpdater(1, chartOneItem, chartOneRange);
      }
    });
  });

  // İkinci grafik kontrolleri
  const chartTwoItemButtons = $.querySelectorAll('#chart-Two-item li');
  chartTwoItemButtons.forEach(item => {
    item.addEventListener('click', () => {
      chartTwoItemButtons.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      chartTwoItem = item.dataset.item;

      if (chartTwoItem === 'ALL') {
        chartUpdater(2, chartTwoItem, chartTwoRange, true, assetsData['dollar_tl'], assetsData['euro_dollar'], assetsData['dxy']);
      } else {
        chartUpdater(2, chartTwoItem, chartTwoRange);
      }
    });
  });

  const chartTwoRangeButtons = $.querySelectorAll('#chart-Two-range li');
  chartTwoRangeButtons.forEach(item => {
    item.addEventListener('click', () => {
      chartTwoRangeButtons.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      chartTwoRange = item.dataset.range;

      if (chartTwoItem === 'ALL') {
        chartUpdater(2, chartTwoItem, chartTwoRange, true, assetsData['dollar_tl'], assetsData['euro_dollar'], assetsData['dxy']);
      } else {
        chartUpdater(2, chartTwoItem, chartTwoRange);
      }
    });
  });

  // Grafik güncelleyici fonksiyon
  function chartUpdater(chart, chartItem, chartRange, multiView = false, ...multiData) {
    let chartObj = chart === 1 ? chartOne : chartTwo;
    let dataSource = chart === 1
      ? { eurostoxx50: assetsData['eurostoxx50'], nikkei225: assetsData['nikkei225'] }
      : { dollar_tl: assetsData['dollar_tl'], euro_dollar: assetsData['euro_dollar'], dxy: assetsData['dxy'] };

    if (multiView) {
      let newLabels = [];
      let newDataset = [];

      multiData.forEach(datasetObj => {
        if (newLabels.length === 0) {
          newLabels = datasetObj[chartRange].labels;
        }
        newDataset.push({
          label: datasetObj.name,
          data: datasetObj[chartRange].data,
          borderColor: datasetObj.color,
          backgroundColor: datasetObj.color,
          borderWidth: 3
        });
      });

      chartObj.data = {
        labels: newLabels,
        datasets: newDataset,
      };
    } else {
      const data = dataSource[chartItem];
      chartObj.data = {
        labels: data[chartRange].labels,
        datasets: [{
          label: chartItem,
          data: data[chartRange].data,
          borderColor: data.color,
          backgroundColor: data.color,
          borderWidth: 3
        }]
      };
    }
    chartObj.update();
  }

  // Birinci grafik oluşturulması
  const ctxOne = document.getElementById('chartOne').getContext('2d');
  const chartOne = new Chart(ctxOne, {
    type: 'line',
    data: {
      labels: assetsData['eurostoxx50']['1M'].labels,
      datasets: [{
        label: 'EuroStoxx 50',
        data: assetsData['eurostoxx50']['1M'].data,
        borderColor: assetsData['eurostoxx50'].color,
        backgroundColor: assetsData['eurostoxx50'].color,
        borderWidth: 3
      }]
    }
  });

  // İkinci grafik oluşturulması
  const ctxTwo = document.getElementById('chartTwo').getContext('2d');
  const chartTwo = new Chart(ctxTwo, {
    type: 'line',
    data: {
      labels: assetsData['dollar_tl']['1M'].labels,
      datasets: [{
        label: 'Dollar/TL',
        data: assetsData['dollar_tl']['1M'].data,
        borderColor: assetsData['dollar_tl'].color,
        backgroundColor: assetsData['dollar_tl'].color,
        borderWidth: 3
      }]
    }
  });
}

function showLoader() {
  document.getElementById('loader1').style.display = 'block';
  document.getElementById('loader2').style.display = 'block';
}

showLoader();

assetsData().then((assetsData) => {
  mainVerivizyon(assetsData);
});
