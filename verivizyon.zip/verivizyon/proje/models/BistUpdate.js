const yahooFinance = require('yahoo-finance2').default;
const connection = require('./db.js');

const SYMBOLS = {
  BIST100: 'XU100.IS',
  BIST30: 'XU030.IS',
};


async function updateIndexData(index, symbol) {
  try {
    const result = await yahooFinance.historical(symbol, {
      period1: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000), // Son 1 yıl
      period2: new Date(), 
      interval: '1d', 
    });

    if (Array.isArray(result)) {
      const prices = result.map(item => parseFloat(item.close));

      const sql = `UPDATE \`${index}\` SET 
        \`1D\` = ?,
        \`1W\` = ?,
        \`1M\` = ?,
        \`1Y\` = ?,
        \`6M\` = ?,
        \`date\` = NOW()
        WHERE 1`;

      const data = [
        JSON.stringify(prices.slice(-1)),      
        JSON.stringify(prices.slice(-7)),
        JSON.stringify(prices.slice(-30)),
        JSON.stringify(getMonthlyPrices(prices, 12)), // 1Y: Son 12 ay fiyatı
        JSON.stringify(getMonthlyPrices(prices, 6)),  // 6M: Son 6 ay fiyatı
      ];

      connection.execute(sql, data, (err, results) => {
        if (err) {
          console.error(`${index} tablosu güncelleme hatası:`, err);
        } else {
          console.log(`${index} tablosu başarıyla güncellendi.`);
        }
      });
    } else {
      console.error('API yanıtı geçersiz veya veri bulunamadı.');
    }
  } catch (error) {
    console.error(`${index} için veri çekme hatası:`, error);
  }
}

function getMonthlyPrices(prices, months) {
  const monthlyPrices = [];
  for (let i = 0; i < months; i++) {
    const startIndex = prices.length - ((i + 1) * 30); // Her ay için 30 gün
    const endIndex = prices.length - (i * 30); // Ayın son günü
    if (startIndex >= 0) {
      const monthPrices = prices.slice(startIndex, endIndex);
      const averagePrice = monthPrices.reduce((sum, price) => sum + price, 0) / monthPrices.length;
      monthlyPrices.push(averagePrice);
    } else {
      break;
    }
  }
  return monthlyPrices.reverse(); // En eski aydan en yenisine doğru
}

module.exports = () => {
  updateIndexData('BIST100', SYMBOLS.BIST100);
  updateIndexData('BIST30', SYMBOLS.BIST30);
}