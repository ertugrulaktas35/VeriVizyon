const axios = require('axios');
const connection = require('./db.js');

async function updateCoinData(coin) {
  const url = `https://api.binance.com/api/v3/klines?symbol=${coin.toUpperCase()}USDT&interval=1d&limit=30`;
  try {
    const response = await axios.get(url);
    if (response.status === 200 && Array.isArray(response.data)) {
      const prices = response.data.map(item => parseFloat(item[4])); // Kapanış fiyatları

      const sql = `UPDATE \`${coin}\` SET 
        \`1D\` = ?,
        \`1W\` = ?,
        \`1M\` = ?,
        \`1Y\` = ?,
        \`6M\` = ?,
        \`date\` = NOW()
        WHERE 1`;  // 'WHERE 1' her kaydı günceller

      const data = [
        JSON.stringify(prices.slice(0, 24)),  // 1D (1 günlük fiyatlar)
        JSON.stringify(prices.slice(0, 7)),   // 1W (1 haftalık fiyatlar)
        JSON.stringify(prices.slice(0, 30)),  // 1M (1 aylık fiyatlar)
        JSON.stringify(prices.slice(0, 12)),  // 1Y (1 yıllık fiyatlar)
        JSON.stringify(prices.slice(0, 6)),   // 6M (6 aylık fiyatlar)
      ];

      connection.execute(sql, data, (err, results) => {
        if (err) {
          console.error('Veritabanı güncelleme hatası:', err);
        } else {
          console.log(`${coin} tablosu başarıyla güncellendi.`);
        }
      });
    } else {
      console.error('API yanıtı geçersiz');
    }
  } catch (error) {
    console.error('API isteği hatası:', error);
  }
}
module.exports = ()=>{
  updateCoinData('btc');
  updateCoinData('eth');
}