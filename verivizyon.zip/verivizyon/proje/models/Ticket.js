const db = require('./db'); // DB bağlantısını import et

// Yeni bir ticket oluştur
const createTicket = (user_id, subject, description, priority, status, callback) => {
  const query = 'INSERT INTO tickets (user_id, subject, description, priority, status) VALUES (?, ?, ?, ?, ?)';
  db.query(query, [user_id, subject, description, priority, status], (err, result) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, result);
  });
};

// Ticket listesi al
const getTickets = (callback) => {
  const query = 'SELECT * FROM tickets';
  db.query(query, (err, results) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, results);
  });
};

// Ticket'a yanıt ekle
const createTicketAnswer = (ticket_id, user_id, answer, callback) => {
  const query = 'INSERT INTO ticket_answers (ticket_id, user_id, answer) VALUES (?, ?, ?)';
  db.query(query, [ticket_id, user_id, answer], (err, result) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, result);
  });
};

// Ticket yanıtlarını al
const getTicketAnswers = (ticket_id, callback) => {
  const query = 'SELECT * FROM ticket_answers WHERE ticket_id = ?';
  db.query(query, [ticket_id], (err, results) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, results);
  });
};

// Ticket durumu güncelle
const updateTicketStatus = (ticket_id, status, callback) => {
  const query = 'UPDATE tickets SET status = ? WHERE id = ?';
  db.query(query, [status, ticket_id], (err, result) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, result);
  });
};

module.exports = {
  createTicket,
  getTickets,
  createTicketAnswer,
  getTicketAnswers,
  updateTicketStatus
};