const yahooFinance = require('yahoo-finance2').default; // Yahoo Finance API
const connection = require('./db.js'); // Veritabanı bağlantısı

// Endeks sembollerini burada tanımlıyoruz
const indices = {
  sp500: '^GSPC',   // S&P 500
  dowjones: '^DJI',  // Dow Jones
  nasdaq: '^IXIC',   // NASDAQ
};

// Endeks güncelleme fonksiyonu
async function updateIndexData(index, symbol) {
  try {
    // Yahoo Finance'dan 1 yıl geriye dönük günlük fiyat verisi alıyoruz
    const data = await yahooFinance.historical(symbol, {
      period1: '2022-12-01', // Başlangıç tarihi
      period2: new Date(),   // Bugünün tarihi
      interval: '1d',        // Günlük interval
    });

    if (data.length > 0) {
      const prices = data.map(item => parseFloat(item.close)); // Kapanış fiyatları

      // Veritabanı güncelleme işlemi
      const sql = `UPDATE \`${index}\` SET 
        \`1D\` = ?,
        \`1W\` = ?,
        \`1M\` = ?,
        \`1Y\` = ?,
        \`6M\` = ?,
        \`date\` = NOW()
        WHERE 1`;

      const dataToUpdate = [
        JSON.stringify(prices.slice(-1)),      // 1D: Son 1 gün fiyatı
        JSON.stringify(prices.slice(-7)),      // 1W: Son 7 gün fiyatı
        JSON.stringify(prices.slice(-30)),     // 1M: Son 30 gün fiyatı
        JSON.stringify(getMonthlyPrices(prices, 12)), // 1Y: Son 12 ay fiyatı
        JSON.stringify(getMonthlyPrices(prices, 6)),  // 6M: Son 6 ay fiyatı
      ];

      connection.execute(sql, dataToUpdate, (err, results) => {
        if (err) {
          console.error(`${index} tablosu güncelleme hatası:`, err);
        } else {
          console.log(`${index} tablosu başarıyla güncellendi.`);
        }
      });
    } else {
      console.error(`${index} için veri bulunamadı.`);
    }
  } catch (error) {
    console.error(`${index} için veri çekme hatası:`, error.message);
  }
}




function getMonthlyPrices(prices, months) {
  const monthlyPrices = [];
  for (let i = 0; i < months; i++) {
    const startIndex = prices.length - ((i + 1) * 30); // Her ay için 30 gün
    const endIndex = prices.length - (i * 30); // Ayın son günü
    if (startIndex >= 0) {
      const monthPrices = prices.slice(startIndex, endIndex);
      const averagePrice = monthPrices.reduce((sum, price) => sum + price, 0) / monthPrices.length;
      monthlyPrices.push(averagePrice);
    } else {
      break;
    }
  }
  return monthlyPrices.reverse(); // En eski aydan en yenisine doğru
}


module.exports = ()=>{
  updateIndexData('sp500', indices.sp500);
  updateIndexData('dowjones', indices.dowjones);
  updateIndexData('nasdaq', indices.nasdaq);
}