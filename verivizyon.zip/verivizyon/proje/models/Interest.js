const connection = require('./db');

// Tüm faiz oranlarını al
const getAllInterestRates = (callback) => {
  const query = 'SELECT * FROM interest_rates';
  connection.query(query, (err, results) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, results);
  });
};

// Belirli bir faiz oranını ID ile al
const getInterestRateById = (id, callback) => {
  const query = 'SELECT * FROM interest_rates WHERE id = ?';
  connection.query(query, [id], (err, results) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, results[0]);  // Sonuç sadece bir satır olacak
  });
};

// Faiz oranını güncelle
const updateInterestRate = (id, aciklanan, beklenti, onceki, aciklanacak_tarih, callback) => {
  const query = 'UPDATE interest_rates SET aciklanan = ?, beklenti = ?, onceki = ?, aciklanacak_tarih = ? WHERE id = ?';
  connection.query(query, [aciklanan, beklenti, onceki, aciklanacak_tarih, id], (err, result) => {
    if (err) {
      return callback(err, null);
    }
    callback(null, result);  // Güncelleme sonuçlarını döndür
  });
};

module.exports = {
  getAllInterestRates,
  getInterestRateById,
  updateInterestRate
};