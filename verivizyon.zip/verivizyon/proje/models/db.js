const mysql = require('mysql2');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD
});

const dbName = process.env.DB_NAME;

connection.connect((err) => {
  if (err) {
    console.error('Veritabanına bağlanırken hata oluştu:', err.stack);
    return;
  }
  console.log('\x1b[32mBağlantı başarıyla sağlandı!\x1b[0m');

  connection.query(`SHOW DATABASES LIKE '${dbName}'`, (err, results) => {
    if (err) {
      console.error('Veritabanı kontrolü hatası:', err);
      return;
    }

    if (results.length === 0) {
      console.log(`Veritabanı '${dbName}' bulunamadı, oluşturuluyor...`);
      connection.query(`CREATE DATABASE ${dbName}`, (err) => {
        if (err) {
          console.error('Veritabanı oluşturulurken hata:', err);
          return;
        }
        console.log(`Veritabanı '${dbName}' başarıyla oluşturuldu.`);
        createTables();
      });
    } else {
      console.log(`Veritabanı '${dbName}' mevcut...`);
      createTables();
    }
  });
});

function createTables() {
  connection.changeUser({ database: dbName }, (err) => {
    if (err) {
      console.error('Veritabanına geçiş yapılırken hata:', err);
      return;
    }
    
    console.log(`\x1b[32mİlk Verti tabanı işlemleri başarıyla sona erdi.\x1b[34m`);
    console.log(`İlk güncelleme birkaç saniye içinde başlayacak...\x1b[0m`);
    const tables = [
      'btc', 'eth', 'altin', 'gumus', 'petrol', 'platin',
      'bist100', 'bist30', 'sp500', 'dowjones', 'nasdaq',
      'eurostoxx50', 'nikkei225', 'dxy', 'euro_dollar', 'dollar_tl',
      'users', 'tickets', 'ticket_answers', 'interest_rates'
    ];

    tables.forEach((table) => {
      checkTableExists(table, (exists) => {
        if (!exists) {
          let createTableQuery = '';
          let insertDataQuery = '';

          if (table === 'users') {
            createTableQuery = `
              CREATE TABLE ${table} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255) NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'client') NOT NULL DEFAULT 'client',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            `;
            insertDataQuery = `INSERT INTO ${table} (username, password, role) VALUES ('admin', 'adminpass', 'admin');`;
          } else if (table === 'tickets') {
            createTableQuery = `
              CREATE TABLE ${table} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                subject VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                status ENUM('open', 'closed', 'in-progress') NOT NULL DEFAULT 'open',
                priority ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            `;
            insertDataQuery = `INSERT INTO ${table} (user_id, subject, description) VALUES (1, 'Hesap Sorunu', 'Hesabımda giriş yapamıyorum, lütfen yardımcı olur musunuz?');`;
          } else if (table === 'ticket_answers') {
            createTableQuery = `
              CREATE TABLE ${table} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id INT DEFAULT NULL,
                user_id INT DEFAULT NULL,
                answer TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES tickets(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            `;
            insertDataQuery = `INSERT INTO ${table} (ticket_id, user_id, answer) VALUES (1, 1, 'Merhaba, hesabınıza erişim sağlayabilmeniz için şifrenizi sıfırladım. Lütfen e-postanızı kontrol edin.');`;
          } else if (table === 'interest_rates') {
            createTableQuery = `
              CREATE TABLE ${table} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                aciklanan DECIMAL(5,2) NOT NULL,
                beklenti DECIMAL(5,2) NOT NULL,
                onceki DECIMAL(5,2) NOT NULL,
                aciklanacak_tarih DATE NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            `;
            insertDataQuery = `
              INSERT INTO ${table} (name, aciklanan, beklenti, onceki, aciklanacak_tarih) VALUES
              ('FED', 5.00, 5.25, 5.50, '2025-01-01'),
              ('TCMB', 3.80, 2.90, 3.50, '2025-02-15'),
              ('ECC', 9.00, 8.00, 9.25, '2025-03-01');
            `;
          } else {
            createTableQuery = `
              CREATE TABLE ${table} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                \`1D\` JSON,
                \`1W\` JSON,
                \`1M\` JSON,
                \`1Y\` JSON,
                \`6M\` JSON
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            `;
            insertDataQuery = `INSERT INTO ${table} (date) VALUES (NOW());`;
          }

          connection.query(createTableQuery, (err) => {
            if (err) {
              console.error(`Tablo ${table} oluşturulurken hata oluştu:`, err);
              return;
            }
            console.log(`Tablo '${table}' başarıyla oluşturuldu.`);

            if (insertDataQuery) {
              connection.query(insertDataQuery, (err) => {
                if (err) {
                  console.error(`Tablo ${table} için veri eklenirken hata oluştu:`, err);
                  return;
                }
                console.log(`Tablo '${table}' için örnek veri başarıyla eklendi.`);
              });
            }
          });
        }
      });
    });
  });
}

function checkTableExists(table, callback) {
  const query = `SHOW TABLES LIKE '${table}'`;
  connection.query(query, (err, result) => {
    if (err) {
      console.error(`Tablo kontrolü hatası: ${err}`);
      return callback(false);
    }
    callback(result.length > 0);
  });
}

module.exports = connection;