const yahooFinance = require('yahoo-finance2').default; // Yahoo Finance kütüphanesi
const connection = require('./db.js'); // Veritabanı bağlantısı

// Endeks güncelleme fonksiyonu
async function updateIndexData(index, symbol) {
  try {
    // Yahoo Finance API'den veri çekme (1 yıllık günlük veriler)
    const result = await yahooFinance.historical(symbol, {
      period1: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000), // 1 yıl öncesi
      period2: new Date(), // Bugün
      interval: '1d', // Günlük interval
    });

    if (Array.isArray(result)) {
      const prices = result.map(item => parseFloat(item.close)); // Kapanış fiyatları

      const sql = `UPDATE \`${index}\` SET 
        \`1D\` = ?,
        \`1W\` = ?,
        \`1M\` = ?,
        \`1Y\` = ?,
        \`6M\` = ?,
        \`date\` = NOW()
        WHERE 1`;

      const data = [
        JSON.stringify(prices.slice(0, 1)),      // 1D: Son 1 gün fiyatı
        JSON.stringify(prices.slice(0, 7)),      // 1W: Son 7 gün fiyatı
        JSON.stringify(prices.slice(0, 30)),     // 1M: Son 30 gün fiyatı
        JSON.stringify(getMonthlyPrices(prices, 12)), // 1Y: Son 12 ay fiyatı
        JSON.stringify(getMonthlyPrices(prices, 6)),  // 6M: Son 6 ay fiyatı
      ];

      connection.execute(sql, data, (err, results) => {
        if (err) {
          console.error(`${index} tablosu güncelleme hatası:`, err);
        } else {
          console.log(`${index} tablosu başarıyla güncellendi.`);
        }
      });
    } else {
      console.error('API yanıtı geçersiz veya veri bulunamadı.');
    }
  } catch (error) {
    console.error(`${index} için veri çekme hatası:`, error);
  }
}


function getMonthlyPrices(prices, months) {
  const monthlyPrices = [];
  for (let i = 0; i < months; i++) {
    const startIndex = prices.length - ((i + 1) * 30); // Her ay için 30 gün
    const endIndex = prices.length - (i * 30); // Ayın son günü
    if (startIndex >= 0) {
      const monthPrices = prices.slice(startIndex, endIndex);
      const averagePrice = monthPrices.reduce((sum, price) => sum + price, 0) / monthPrices.length;
      monthlyPrices.push(averagePrice);
    } else {
      break;
    }
  }
  return monthlyPrices.reverse(); // En eski aydan en yenisine doğru
}


module.exports = ()=>{
  updateIndexData('eurostoxx50', '^STOXX50E');   // Eurostoxx 50
  updateIndexData('nikkei225', '^N225');           // Nikkei 225`
}