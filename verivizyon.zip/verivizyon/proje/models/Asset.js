const db = require('./db');

function getData(asset, timeframe) {
  const query = `SELECT ${timeframe} FROM ${asset}`;
  
  return new Promise((resolve, reject) => {
    db.query(query, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
}

module.exports = { getData };