const BistUpdate = require('./BistUpdate');
const CommoditiesUpdate = require('./CommoditiesUpdate');
const CryptoUpdate = require('./CryptoUpdate');
const CurrencyIndicesUpdate = require('./CurrencyIndicesUpdate');
const GlobalStocksUpdate = require('./GlobalStocksUpdate');
const USStocksUpdate = require('./USStocksUpdate');
const db = require('./db'); // Database bağlantınızı sağlayan modül
const dbName = process.env.DB_NAME;

const updateAll = () => {
    BistUpdate();
    CommoditiesUpdate();
    CryptoUpdate();
    CurrencyIndicesUpdate();
    GlobalStocksUpdate();
    USStocksUpdate();
};

const autoUpdate = async () => {
    try {
        // Database bağlantısı ve sorgu
        const query = `SELECT date FROM ${dbName}.btc LIMIT 1`;
        db.query(query, (error, results) => {
            if (error) {
                console.error('Veritabanı sorgusu sırasında bir hata oluştu:', error);
                return;
            }

            if (results.length === 0) {
                updateAll();
                return;
            }

            const lastUpdateDate = new Date(results[0].date);
            const currentTime = new Date();

            // 1 saatlik fark kontrolü
            const oneHourInMilliseconds = 60 * 60 * 1000;
            const timeDifference = currentTime - lastUpdateDate;

            if (timeDifference >= oneHourInMilliseconds) {
                console.log('1 saat geçti, güncelleme yapılıyor...');
                updateAll();
            } else {
                const remainingTime = oneHourInMilliseconds - timeDifference;
                const minutes = Math.floor((remainingTime / (1000 * 60)) % 60);
                const seconds = Math.floor((remainingTime / 1000) % 60);
                console.log(`\x1b[34mGelecek güncellemeye ${minutes} dakika ${seconds} saniye kaldı.\x1b[0m`);
            }
        });
    } catch (error) {
        console.error('Otomatik güncelleme sırasında bir hata oluştu:', error);
    }
};

module.exports = {
    updateAll,
    autoUpdate,
};
