const yahooFinance = require('yahoo-finance2').default;
const connection = require('./db.js');

const commodities = {
  altin: 'GC=F',  
  gumus: 'SI=F',  
  petrol: 'CL=F', 
  platin: 'PL=F',
};

async function updateCommodityData(commodity, symbol) {
  try {
    const data = await yahooFinance.historical(symbol, {
      period1: '2022-12-01', // baslangic
      period2: new Date(),   // bugun
      interval: '1d',        // gunluk interval
    });

    if (data.length > 0) {
      const prices = data.map(item => parseFloat(item.close));
      const sql = `UPDATE \`${commodity}\` SET 
        \`1D\` = ?,
        \`1W\` = ?,
        \`1M\` = ?,
        \`1Y\` = ?,
        \`6M\` = ?,
        \`date\` = NOW()
        WHERE 1`;

      const dataToUpdate = [
        JSON.stringify(prices.slice(-1)),
        JSON.stringify(prices.slice(-7)),
        JSON.stringify(prices.slice(-30)),
        JSON.stringify(getMonthlyPrices(prices, 12)), // 1Y: Son 12 ay fiyatı
        JSON.stringify(getMonthlyPrices(prices, 6)),  // 6M: Son 6 ay fiyatı
      ];

      connection.execute(sql, dataToUpdate, (err, results) => {
        if (err) {
          console.error(`${commodity} tablosu güncelleme hatası:`, err);
        } else {
          console.log(`${commodity} tablosu başarıyla güncellendi.`);
        }
      });
    } else {
      console.error(`${commodity} için veri bulunamadı.`);
    }
  } catch (error) {
    console.error(`${commodity} için veri çekme hatası:`, error.message);
  }
}


function getMonthlyPrices(prices, months) {
  const monthlyPrices = [];
  for (let i = 0; i < months; i++) {
    const startIndex = prices.length - ((i + 1) * 30); // Her ay için 30 gün
    const endIndex = prices.length - (i * 30); // Ayın son günü
    if (startIndex >= 0) {
      const monthPrices = prices.slice(startIndex, endIndex);
      const averagePrice = monthPrices.reduce((sum, price) => sum + price, 0) / monthPrices.length;
      monthlyPrices.push(averagePrice);
    } else {
      break;
    }
  }
  return monthlyPrices.reverse(); // En eski aydan en yenisine doğru
}

module.exports = () => {
  updateCommodityData('altin', commodities.altin);
  updateCommodityData('gumus', commodities.gumus);
  updateCommodityData('petrol', commodities.petrol);
  updateCommodityData('platin', commodities.platin);
}