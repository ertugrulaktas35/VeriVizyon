const interestRateModel = require('../models/Interest');

// Tüm faiz oranlarını al
exports.getAllInterestRates = (req, res) => {
  interestRateModel.getAllInterestRates((err, results) => {
    if (err) {
      console.error('Error in getAllInterestRates controller:', err);
      return res.status(500).json({ message: 'Sunucu hatası' });
    }
    return res.status(200).json(results);
  });
};

// Belirli bir faiz oranını ID ile al
exports.getInterestRateById = (req, res) => {
  const { id } = req.params;

  interestRateModel.getInterestRateById(id, (err, interestRate) => {
    if (err) {
      console.error('Error in getInterestRateById controller:', err);
      return res.status(500).json({ message: 'Sunucu hatası' });
    }
    if (!interestRate) {
      return res.status(404).json({ message: 'Faiz oranı bulunamadı' });
    }
    return res.status(200).json(interestRate);
  });
};

// Faiz oranını güncelle
exports.updateInterestRate = (req, res) => {
  const { id } = req.params;
  const { aciklanan, beklenti, onceki, aciklanacak_tarih } = req.body;

  interestRateModel.updateInterestRate(id, aciklanan, beklenti, onceki, aciklanacak_tarih, (err, result) => {
    if (err) {
      console.error('Error in updateInterestRate controller:', err);
      return res.status(500).json({ message: 'Sunucu hatası' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Faiz oranı bulunamadı' });
    }

    return res.status(200).json({ message: 'Faiz oranı başarıyla güncellendi.' });
  });
};