const ticketModel = require('../models/Ticket'); // Ticket modelini import et

// Yeni ticket oluştur
exports.createTicket = (req, res) => {
  const { user_id, subject, description, priority, status } = req.body;

  if (!user_id || !subject || !description || !priority || !status) {
    return res.status(400).json({ message: "Eksik alanlar var." });
  }

  ticketModel.createTicket(user_id, subject, description, priority, status, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Ticket oluşturulurken bir hata oluştu." });
    }
    res.status(201).json({ message: 'Ticket başarıyla oluşturuldu', ticketId: result.insertId });
  });
};

// Ticketları listele
exports.getTickets = (req, res) => {
  ticketModel.getTickets((err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Ticketlar listelenirken bir hata oluştu." });
    }
    res.status(200).json({ tickets: results });
  });
};

// Ticket'a yanıt oluştur
exports.createTicketAnswer = (req, res) => {
  const { ticket_id, user_id, answer } = req.body;

  if (!ticket_id || !user_id || !answer) {
    return res.status(400).json({ message: "Ticket ID, User ID ve Yanıt gereklidir." });
  }

  ticketModel.createTicketAnswer(ticket_id, user_id, answer, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Yanıt oluşturulurken bir hata oluştu." });
    }
    res.status(201).json({ message: 'Yanıt başarıyla eklendi', answerId: result.insertId });
  });
};

// Ticket yanıtlarını listele
exports.getTicketAnswers = (req, res) => {
  const { ticket_id } = req.params;

  ticketModel.getTicketAnswers(ticket_id, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Ticket yanıtları listelenirken bir hata oluştu." });
    }
    res.status(200).json({ answers: results });
  });
};

// Ticket durumu güncelle
exports.updateTicketStatus = (req, res) => {
  const { ticket_id, status } = req.body;

  if (!ticket_id || !status) {
    return res.status(400).json({ message: "Ticket ID ve durum gereklidir." });
  }

  ticketModel.updateTicketStatus(ticket_id, status, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Ticket durumu güncellenirken bir hata oluştu." });
    }
    res.status(200).json({ message: 'Ticket durumu başarıyla güncellendi.' });
  });
};