const asstsModel = require('./../models/Asset');

const getData = async (req, res) => {
    const { asset, timeframe } = req.params;
    
    try {
        const results = await asstsModel.getData(asset, timeframe); 
        
        if (results.length === 0) {
            return res.status(404).json({ error: 'Bu asset için data bulunamadı' });
        }
        
        res.json(results);
    } catch (err) {
        console.error('Veritabanı Hatası:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = {
    getData,
};