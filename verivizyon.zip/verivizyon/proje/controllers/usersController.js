const userModel = require('../models/User'); // userModel dosyasını import et

// Kullanıcı oluşturma API'si
exports.createUser = (req, res) => {
  const { username, password, role } = req.body;

  if (!username || !password || !role) {
    return res.status(400).json({ message: "Username, password ve role alanları gereklidir." });
  }

  userModel.createUser(username, password, role, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Kullanıcı oluşturulurken bir hata oluştu." });
    }
    res.status(201).json({ message: 'Kullanıcı başarıyla oluşturuldu', userId: result.insertId });
  });
};

// Kullanıcı silme API'si
exports.deleteUser = (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ message: "Kullanıcı ID'si gereklidir." });
  }

  userModel.deleteUser(id, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Kullanıcı silinirken bir hata oluştu." });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Kullanıcı bulunamadı." });
    }
    res.status(200).json({ message: 'Kullanıcı başarıyla silindi.' });
  });
};

// Kullanıcıları listeleme API'si
exports.getUsers = (req, res) => {
  userModel.getUsers((err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Kullanıcılar listelenirken bir hata oluştu." });
    }
    res.status(200).json({ users: results });
  });
};

