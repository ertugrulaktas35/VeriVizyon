const express = require('express');
const router = express.Router();
const usersController = require('../controllers/usersController'); // Controller'ı import et

// Kullanıcı oluşturma (POST)
router.post('/', usersController.createUser);

// Kullanıcı silme (DELETE)
router.delete('/:id', usersController.deleteUser);

// Kullanıcıları listeleme (GET)
router.get('/', usersController.getUsers);

module.exports = router;