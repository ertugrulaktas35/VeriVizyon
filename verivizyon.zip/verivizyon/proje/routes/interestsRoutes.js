const express = require('express');
const router = express.Router();
const interestRateController = require('../controllers/interestsController');

// Tüm faiz oranlarını al
router.get('/', interestRateController.getAllInterestRates);

// Belirli bir faiz oranını ID ile al
router.get('/:id', interestRateController.getInterestRateById);

// Faiz oranını güncelle
router.put('/:id', interestRateController.updateInterestRate);

module.exports = router;