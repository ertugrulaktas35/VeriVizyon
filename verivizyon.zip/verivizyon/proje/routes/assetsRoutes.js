const express = require('express');
const assetsController = require('./../controllers/assetsController')
const router = express.Router();
router.get('/:asset/:timeframe', assetsController.getData);
module.exports = router;