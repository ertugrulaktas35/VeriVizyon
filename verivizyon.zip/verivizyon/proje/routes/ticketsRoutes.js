const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketsController'); // Controller'ı import et

// Yeni ticket oluştur (POST)
router.post('/', ticketController.createTicket);

// Ticketları listele (GET)
router.get('/', ticketController.getTickets);

// Ticket'a yanıt ekle (POST)
router.post('/answer', ticketController.createTicketAnswer);

// Ticket yanıtlarını listele (GET)
router.get('/answers/:ticket_id', ticketController.getTicketAnswers);

// Ticket durumunu güncelle (PUT)
router.put('/status', ticketController.updateTicketStatus);

module.exports = router;